"# single-spa-demo-root-config" 
